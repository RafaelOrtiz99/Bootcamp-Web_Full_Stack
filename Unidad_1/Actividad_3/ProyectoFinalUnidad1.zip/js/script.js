function enviarDatos() {
    let nombre = document.getElementById('nombre').value;
    alert('Gracias ' + nombre + ' por ponerte en contacto con nosotros');
}